#This script has a reproducible example of the wrapper script error

require(phytools)
require(RPANDA)

set.seed(1234)

phylo<-pbtree(n=50,nsim=1)
regions<-c("trop","trop","trop","temp","temp")
samp.reg<-sample(regions)
trait<-c(rep(samp.reg[1],10),rep(samp.reg[2],10),rep(samp.reg[3],10),rep(samp.reg[4],10),rep(samp.reg[5],10))
names(trait)<-phylo$tip.label
smap<-make.simmap(phylo,trait,model="ARD")

trait<-rnorm(50)
names(trait)<-phylo$tip.label

source('fit_t_DD_BETA.R')


o1b<-fit_t_DD(phylo=phylo,data=trait,model="exponential",regime.map=smap)

#this crashes with an error:

#Error: $ operator is invalid for atomic vectors
#In addition: There were 50 or more warnings (use warnings() to see the first 50)

#yet, when I just copy and paste the code that is in fit_t_DD, it runs fine without crashing

phylo=phylo
data=trait
model="exponential"
regime.map=smap
beta=NULL
sigma=NULL
method=c("L-BFGS-B")
upper=Inf
lower=-20
control=list(maxit=20000)
diagnostic=TRUE
echo=TRUE
error=NULL

		#first check that regime.map and phylo and data are concordant
		if(!all(as.phylo(phylo)$tip.label == as.phylo(regime.map)$tip.label)) { stop("regime map doesn't match phylogeny")}
		if(length(data) != length(as.phylo(regime.map)$tip.label)) { stop("number of lineages in data and regime map don't match")}
		if(! all (names(data) %in% as.phylo(regime.map)$tip.label)) { stop("names of lineages in data and regime map don't match")}
		if(! all (as.phylo(regime.map)$tip.label %in% names(data)) ) { stop("names of lineages in data and regime map don't match")}
		
		class.object<-try(CreateClassObject(regime.map))
		if(class(class.object)=="try-error"){class.object<-try(CreateClassObject(regime.map,rnd=6))}
		if(class(class.object)=="try-error"){class.object<-CreateClassObject(regime.map,rnd=7)}

		class.df<-return.class.df_subgroup(regime.map,class.object)
		new_list_function<-create.function.list(regime.map,class.object,class.df)
		
		#calculate maxN if DDlin, set to NA if DDexp
		
		maxN<-ifelse(model=="linear",max(class.df[,-1]),NA)
		
		#fit model
		sigma.constraint<-rep(1, dim(regime.map$mapped.edge)[2])
		beta.constraint<-seq(1,by=1,length.out=dim(regime.map$mapped.edge)[2])
		
		out<-fit_t_general(tree=regime.map,data=data,fun=new_list_function,error=error, sigma=sigma, beta=beta, model=model,method=method,maxN=maxN, upper=upper, lower=lower, control=control,diagnostic=diagnostic, echo=echo,constraint=list(sigma=sigma.constraint, beta=beta.constraint))

#I think (but am not 100% certain) that this is because "new_list_function" contains a reference to "class.object$times" and "class.df", which are defined in the console but not passed directly to fit_t_general

#Note, now if you run the script at line 21, it works fine without crashing...