#This script has a reproducible example of the optimisation issues with fit_t_general.R


require(phytools)
require(RPANDA)

set.seed(1234)

fiftytipyuletrees<-pbtree(n=50,nsim=1)
regions<-c("trop","trop","trop","temp","temp")
phylo<-fiftytipyuletrees
samp.reg<-sample(regions)
trait<-c(rep(samp.reg[1],10),rep(samp.reg[2],10),rep(samp.reg[3],10),rep(samp.reg[4],10),rep(samp.reg[5],10))
names(trait)<-phylo$tip.label
smap<-make.simmap(phylo,trait,model="ARD")

source('sim_DDmulti.R')
source('DDexpMulti_nogeo_ADiag.R')
source('DDlinMulti_nogeo_ADiag.R')
source('resortSMatrix.R')
source('CreateSMatrix.R')
source('fit_t_general_options_old.R')
source('generalized_functions.R')

r.matrix= CreateSMatrix(CreateClassObject(smap),S.cats=c("trop","temp"))
trait<-try(sim_multiDD(smap,pars=matrix(c(0.05,-0.05,-0.1,0),nrow=1),plot=F,S.matrix=r.matrix,rnd=5,model="exponential"))


###now fitting model with RPANDA tools:

rmats<-resortSMatrix(phylo,r.matrix)
ddl.ob<-createModel_DDlin_multi(phylo,rmats)
params0<-c(0,log(sqrt(var(trait[1,])/max(nodeHeights(phylo)))),-1e-4,-1e-4)	
o1al<-fitTipData(ddl.ob,trait[1,],params0,GLSstyle=TRUE)


##now fitting model with fit_t_general tools

phylo=phylo
data=trait[1,]
model="linear"
regime.map=smap
beta=NULL
sigma=NULL
method=c("L-BFGS-B")
upper=Inf
lower=-20
control=list(maxit=20000)
diagnostic=TRUE
echo=TRUE
error=NULL

		#first check that regime.map and phylo and data are concordant
		if(!all(as.phylo(phylo)$tip.label == as.phylo(regime.map)$tip.label)) { stop("regime map doesn't match phylogeny")}
		if(length(data) != length(as.phylo(regime.map)$tip.label)) { stop("number of lineages in data and regime map don't match")}
		if(! all (names(data) %in% as.phylo(regime.map)$tip.label)) { stop("names of lineages in data and regime map don't match")}
		if(! all (as.phylo(regime.map)$tip.label %in% names(data)) ) { stop("names of lineages in data and regime map don't match")}
		
		class.object<-try(CreateClassObject(regime.map))
		if(class(class.object)=="try-error"){class.object<-try(CreateClassObject(regime.map,rnd=6))}
		if(class(class.object)=="try-error"){class.object<-CreateClassObject(regime.map,rnd=7)}

		class.df<-return.class.df_subgroup(regime.map,class.object)
		new_list_function<-create.function.list(regime.map,class.object,class.df)
		
		#calculate maxN if DDlin, set to NA if DDexp
		
		maxN<-ifelse(model=="linear",max(class.df[,-1]),NA)
		
		#fit model
		sigma.constraint<-rep(1, dim(regime.map$mapped.edge)[2])
		beta.constraint<-seq(1,by=1,length.out=dim(regime.map$mapped.edge)[2])
		
		out<-fit_t_general(tree=regime.map,data=data,fun=new_list_function,error=error, sigma=sigma, beta=beta, model=model,method=method,maxN=maxN, upper=upper, lower=lower, control=control,diagnostic=diagnostic, echo=echo,constraint=list(sigma=sigma.constraint, beta=beta.constraint))
		print(out)
		
##note that model doesn't converge (convergence message == 52) using  L-BFGS-B or Nelder-Mead

method="BB"

		out<-fit_t_general(tree=regime.map,data=data,fun=new_list_function,error=error, sigma=sigma, beta=beta, model=model,method=method,maxN=maxN, upper=upper, lower=lower, control=control,diagnostic=diagnostic, echo=echo,constraint=list(sigma=sigma.constraint, beta=beta.constraint))
		print(out)
		
##now model converges fine

##however, the likelihood of this fit is 39.33939, which is close to, but far enough from 39.99859 (from the RPANDA approach above) to be worrying

##looking at the likelihood of the RPANDA version using the ML parameters from the fit_t_general approach:

-getDataLikelihood(ddl.ob, trait[1,], params=c(out$anc,log(sqrt(out$rates[2,1])),out$rates[1,2],out$rates[1,1]))

##returns 39.3478, which is very near the ML estimate from fit_t_general, which leads me to conclude that while the two scripts produce similar likelihoods, the optimiser isn't hitting the ML value in the fit_t_general script

